# Rapid Web
欢迎使用Rapid Web，Rapid Web是一个正在构建中的可视化无代码编程应用，由一位喜爱编程的小学生和一位啥也不是的初中生开发。如果你有好想法，可以将邮件提交给wtly@sudacode.cn
### 版本号
当前构建版本为DEV.22XXXXX，当前无正式版本
### 介绍
没什么好说的，这只是两个鸽子随便鸽的咕咕项目。
### 使用的开源项目
CSS部分使用Bootstrap，JavaScript使用jQuery、jQuery-UI