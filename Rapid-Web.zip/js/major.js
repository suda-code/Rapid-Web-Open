$(".Control-button").click(function(){
    
})
  $("#flip1").click(function(){
    $("#panel1").slideToggle("fast");
  });
  $("#flip2").click(function(){
    $("#panel2").slideToggle("fast");
  });
  $("#flipx").click(function(){
    $("#panel").slideToggle("fast");
  });
  $("#flip8").click(function(){
    $("#panel8").slideToggle("fast");
  });
