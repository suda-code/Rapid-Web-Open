window.onload=()=>{
    document.getElementById("flip4").innerHTML="DEV.2210191每日构建"
    document.getElementById("contn1").innerHTML="DEV.2210191每日构建（内部版本D10）更新如下：<br>去掉了开关。"
  }
  